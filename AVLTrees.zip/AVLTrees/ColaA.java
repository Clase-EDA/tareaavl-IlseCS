package AVLTrees;

import java.util.ArrayList;

public class ColaA <T> implements ColaADT <T> {
    private T[] cola;
    private int inicio;
    private int fin;
    private final int MAX=20;
    
    //constructor
    public ColaA(){
        cola = (T[])new Object [MAX];
        inicio=-1;
        fin=-1;
    }
    
    //constructor con máximo que da el usuario
    public ColaA (int max){
        cola = (T[])new Object [max];
        inicio=-1;
        fin=-1;
    }
    
    public boolean estaVacia (){
        return inicio==-1;
    }
    
    public T consultaInicio (){
        if (estaVacia())
            throw new EmptyCollectionException ();
        
        return cola[inicio];
    }
    
    public void agrega (T dato){
        if (estaVacia())
            inicio=0; //inicio++
        else
            if ((fin+1)%cola.length==inicio)
                expande();
        fin=(fin+1)%cola.length;
        cola[fin]=dato;
    }
    
    private void expande (){
        T[] nuevo=(T[])new Object[cola.length+2];
        /* ciclo para pasarlos también puede sesr con dos fors
        inicio -> .length
        0 < inicio
        */
        int i,n,j;
        n=cola.length;
        for (i=0;i<n;i++){
            j=(inicio+i)%n;
            nuevo[i]=cola[j];
        }//Cierre del for
        inicio=0;
        fin=n-1;
        cola=nuevo;
    }
    
    public T quita (){
        if (estaVacia())
            throw new EmptyCollectionException ();
        T resultado;
        resultado=cola[inicio];
        if (inicio==fin){
            inicio=-1;
            fin=-1;
        }//cierre del if
        else
            inicio=(inicio+1)%cola.length;
        
        return resultado; 
    }//fin del método
    
    public String toString (){
        StringBuilder resp = new StringBuilder();
        //verificar que la cola no está vacía
        if (inicio>=0){
            //caso en el que no es circular
            if (inicio<fin){
                for (int i=0;i<=fin;i++)
                    resp.append(cola[i]).append(" ");
            }//cierre del if
            else{ //caso en el que es circular
                int n=inicio-fin;
                //para agregar del inicio al length
                for (int j=inicio;j<n-1;j++)
                    resp.append(cola[j]).append(" ");
                //para agregar del principio de la cola al inicio
                for (int k=0;k<inicio;k++)
                    resp.append(cola[k]).append(" ");
            }//fin del else
        }//cierre del if
        return resp.toString();
    }//fin del método
    
    /*Ejercicio 36
    Modifica la interface ColaADT y la clase ColaA de tal manera que se 
    agregue la siguiente funcionalidad, por medio de métodos no destructivos: 
 
    a) cuentaElementos(): regresa el total de elementos almacenados en la cola. 
    b) consultaUltimo(): regresa el último elemento almacenado en la cola, sin quitarlo. 
    c) multiQuita(int n): regresa un ArrayList almacenando los n elementos quitados de la cola.  
    */
    
    //regresa el total de elementos almacenados en la cola.
    public int cuentaElementos(){
        int total;
        if (inicio==-1)
            total=0;
        else
            if (inicio<=fin)
                total=fin-inicio+1;
        else
                total=cola.length-(inicio-fin)+1;
        
        return total;
    }//fin del método
    
    //regresa el último elemento almacenado en la cola, sin quitarlo.
    public T consultaUltimo(){
        if (estaVacia())
            throw new EmptyCollectionException ();
        
        return cola[fin];  
    }//fin del método
    
    //regresa un ArrayList almacenando los n elementos quitados de la cola
    public ArrayList <T> multiQuita (int n){
        //verificar que la cola no esté vacía o sea nula
        if (!estaVacia() && cola!=null){
            //para verificar que se puedan sacar todos los elementos requeridos
            int numElem=cuentaElementos();
            if (numElem>=n){
                ArrayList <T> arre = new ArrayList();
                for (int i=0;i<n;i++)
                    arre.add(cola[i]);
                return arre;
            }//cierre del if pequeño
            else
                throw new EmptyCollectionException ("\nNo hay elementos suficientes");
        }//cierre del if grande
        else
            throw new EmptyCollectionException ("\nPila vacía");
    }//fin del método
    
    /*
    Problema 2 [3.5 puntos, 4 puntos si es recursivo]
    
    En la clase ColaA debes agregar el método noHayVecinosIguales() que regrese true si en la
    cola NO hay dos elementos consecutivos iguales. En caso contrario debe regresar false. 
    Al finalizar el método, la cola no debe quedar modificada.
    
    Completa el método main de la clase SegundoParcialEDabril 2015 para probar tu solución.
    (Puedes usar lo que ya está, si lo consideras conveniente)
    */
    
//    public boolean noHayVecinosIguales(){
//        
//    }//fin del método
    
    
            
    
    
}
