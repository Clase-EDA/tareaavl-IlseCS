package AVLTrees;



import java.util.ArrayList;

public interface ColaADT <T> {
    
    public boolean estaVacia();
    public T consultaInicio();
    public void agrega (T dato);
    public T quita ();
    public String toString ();
    
    /*Ejercicio 36
    Modifica la interface ColaADT y la clase ColaA de tal manera que se 
    agregue la siguiente funcionalidad, por medio de métodos no destructivos: 
 
    a) cuentaElementos(): regresa el total de elementos almacenados en la cola. 
    b) consultaUltimo(): regresa el último elemento almacenado en la cola, sin quitarlo. 
    c) multiQuita(int n): regresa un ArrayList almacenando los n elementos quitados de la cola.  
    */
    public int cuentaElementos();
    public T consultaUltimo();
    public ArrayList <T> multiQuita (int n);
    
    
}
