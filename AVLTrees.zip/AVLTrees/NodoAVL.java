package AVLTrees;

/** 
 * <pre>
 * Clase NodoAVL
 * 
 * Clase que define la estructura NodoAVL que servirá para almacenar y enlazar
 * los datos guardados en un AVLTree.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class NodoAVL <T extends Comparable <T>> {
    protected int height;
    protected int fe;
    protected T element;
    NodoAVL <T> izq, der, papa;
    
    //constructor vacío
    public NodoAVL (){
        
    }

    //constructor
    public NodoAVL (T element){
        this.element = element;
    }//end constructor
    
    //gets
    public int getAltura() {
        return height;
    }

    public int getFe() {
        return fe;
    }

    public T getElement() {
        return element;
    }

    public NodoAVL<T> getIzq() {
        return izq;
    }

    public NodoAVL<T> getDer() {
        return der;
    }

    public NodoAVL<T> getPapa() {
        return papa;
    }
    
    //sets
    public void setAltura(int altura) {
        this.height = altura;
    }

    public void setFe(int fe) {
        this.fe = fe;
    }

    public void setElement(T element) {
        this.element = element;
    }

    public void setIzq(NodoAVL<T> izq) {
        this.izq = izq;
    }

    public void setDer(NodoAVL<T> der) {
        this.der = der;
    }

    public void setPapa(NodoAVL<T> papa) {
        this.papa = papa;
    }
    
    //toString
    @Override
    public String toString() {
        return "NodoAVL" + "\nDato: " + element + "\nFactor de equilibrio: " + fe;
    }
    
}//end NodoAVL
