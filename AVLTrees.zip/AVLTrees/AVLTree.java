package AVLTrees;

import java.util.ArrayList;
import java.util.Iterator;

/** 
 * <pre>
 * Clase AVLTree
 * 
 * Clase que contiene los método snecesarios para insertar, borrar, buscar e 
 * imprimir los datos (forma LevelOrder) de un AVLTree.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class AVLTree <T extends Comparable<T>> {
    protected NodoAVL <T> root;
    protected int count;
    
    //constructor
    protected AVLTree (){
        root=null;
        count=0;
    }
    
    //gets
    public int getCount() {
        return count;
    }
    
    //método para calcular el tamaño
    public int size(){
        return count;
    }
    
    //método para ver si está vacío
    public boolean isEmpty(){
        return root==null;
    }
    
    //método para calcular la altura del árbol
    public int height(){
        if (root==null)
            return 0;
        return root.height;
    }//end calcAltTree
    
    //método público para insertar datos en el árbol
    public boolean inserta (T elem){
        boolean resp=true;
        //verificar que el elemento sea diferente de nulo
        if (elem!=null){
            //asegurarse que el elemento no esté en el árbol
            NodoAVL <T> node = new NodoAVL();
            node=busca(elem); 
            //significa que el elemento ya está en el árbol
            if (node!=null){
                resp=false;
                return resp;
            } else {
                root=inserta(root,elem);
                //aumentar contador
                count++;
                return resp;
            }//cierre del else    
        } else 
            throw new EmptyCollectionException ("Elemento nulo");
    }//end inserta público

//------------------------- SECCIÓN INSERTAR -----------------------------------   
    
    //método privado para insertar datos en el árbol
    private NodoAVL inserta (NodoAVL <T> actual, T elem){
        //para insertar
        if (actual==null)
            return new NodoAVL <T>(elem);
        //para ir recorriendo el árbol
        if (elem.compareTo(actual.getElement())<0){
            //nuevo nodo se va a la izquierda
            actual.izq=inserta(actual.izq,elem);
        } else {
            //el valor es más pequeño y el nuevo nodo se va a la derecha
            actual.der=inserta(actual.der,elem);
        }//cierre del else
        //para update el factor de equilibrio y la altura
        actualiza(actual);
        //para checar los casos y balancear si necesario
        NodoAVL <T> aux = new NodoAVL();
        aux=balancea(actual);
        return aux;
    }//end inserta privado
    
    //método auxiliar de inserta que se encarga de update el fe y altura
    private void actualiza (NodoAVL <T> actual){
        //Nota: condition ? if true : if false
        int altIzq;
        //para calcular altura de lado izquierdo
        altIzq=(actual.izq==null) ? -1 : actual.izq.height; 
        int altDer;
        //para calcular altura de lado derecho
        altDer=(actual.der==null) ? -1 : actual.der.height;
        //para actualizar la altura del nodo actual
        actual.setAltura(1+Math.max(altIzq, altDer));
        //utilizar las alturas para sacar el fe del nodo actual
        actual.setFe(altDer-altIzq);
    }//end actualiza
    
    /* método auxiliar de inserta que analiza el factor de equilibrio del nodo
     * y determina qué tipo de rotación se necesita (como un switch)*/
    private NodoAVL <T> balancea (NodoAVL <T> actual){
        //checar si el árbol está más pesado a la izquierda
        if (actual.getFe()==-2){
            //caso rotación izquierda-izquierda
            if (actual.izq.getFe()<=0)
                return rotIzqIzq(actual);
            else //caso rotación izquierda-derecha
                return rotIzqDer(actual);
        } else { 
            //significa que el árbol está más pesado a la derecha
            if (actual.getFe()==+2){
              //caso rotación derecha-derecha
              if (actual.der.getFe()>=0)
                  return rotDerDer(actual);
              else //caso rotación derecha-izquierda
                  return rotDerIzq(actual);
            }//cierre del if interno
        }//cierre del else
        //si no pasa por ninguno de esos casos entonces no se necesita balancear
        return actual;
    }//end balancea
    
    //Empiezan métodos para hacer los cuatro tipos de rotaciones posibles
    
    //caso rotación izquierda-izquierda
    private NodoAVL <T> rotIzqIzq (NodoAVL <T> actual) {
        /* se sube el nodo de en medio por lo tanto se hace una sola rotación 
         * hacia la derecha */
        return rotDer(actual);
    }//end rotIzqIzq
    
    //caso rotación izquierda-derecha
    private NodoAVL <T> rotIzqDer (NodoAVL <T> actual) {
        //primero se hace una rotación a la izquierda
        actual.izq = rotIzq(actual.getIzq());
        //para completar se necesita una rotación izquierda-izquierda
        return rotIzqIzq(actual);
    }//end rotIzqDer

    //caso rotación derecha-derecha
    private NodoAVL <T> rotDerDer (NodoAVL <T> actual) {
        /* se sube el nodo de en medio por lo tanto se hace una sola rotación 
         * hacia la izquierda */
        return rotIzq(actual);
    }//end rotDerDer

    //caso rotación derecha-izquierda
    private NodoAVL <T> rotDerIzq (NodoAVL <T> actual) {
        //primero se hace una rotación a la derecha
        actual.der = rotDer(actual.getDer());
        //para completar se necesita una rotación derecha-derecha
        return rotDerDer(actual);
    }//end rotDerIzq
    
    //Empiezan rotaciones auxiliares simples
    
    //método para hacer rotación izquierda
    private NodoAVL <T> rotIzq (NodoAVL <T> actual) {
        //para asignar al papá y usarlo como auxiliar
        NodoAVL <T> nuevoPapa = actual.der;
        //hacer rotación
        actual.der = nuevoPapa.izq;
        nuevoPapa.izq = actual;
        //para actualizar fe y altura
        actualiza(actual);
        //para actualizar al papá
        actualiza(nuevoPapa);
        return nuevoPapa;
    }//end rotIzq
    
    private NodoAVL <T> rotDer (NodoAVL <T> actual) {
        //para asignar al papá y usarlo como auxiliar
        NodoAVL <T> newParent = actual.izq;
        //hacer rotación
        actual.izq = newParent.der;
        newParent.der = actual;
        //para actualizar fe y altura
        actualiza(actual);
        //para actualizar fe y altura
        actualiza(newParent);
        return newParent;
    }//end rotDer
    
//--------------------------- SECCIÓN BORRAR ----------------------------------- 
    
    //método público para borrar los elementos de un árbol
    public boolean borra (T elem) {
        boolean resp=false;
        //verificar que no se le den datos nulos
        if (elem==null) 
            throw new EmptyCollectionException("Dato nulo");
        //nodo auxiliar para buscar el elemento
        NodoAVL <T> aux = new NodoAVL();
        aux=busca(elem);
        //si el elemento se encuentra en el árbol
        if (aux!=null){
            root=borra(root,elem);
            //disminuir contador
            count--;
            resp=true;
            return resp;
        }//cierre del if
        return resp;
    }//fin de borra

    //método privado para borrar los elementos de un árbol
    private NodoAVL <T> borra (NodoAVL <T> actual, T elem) {
        //ver si elemento está en el lado izquierdo
        if (elem.compareTo(actual.getElement())<0){
            actual.izq=borra(actual.izq,elem);
        } else if (elem.compareTo(actual.getElement())>0){
            //ver si el elemento está en el lado derecho
            actual.der=borra(actual.der,elem);
        } else {
            //caso sección derecha
            if (actual.izq==null)
                return actual.der;
            //caso sección izquierda
            else if (actual.der==null)
                return actual.izq;
            else {
                //caso con dos hijos
                //para borrar del lado izquierdo
                if (actual.izq.height>actual.der.height){
                    //swap
                    T sucIn=findMax(actual.izq);
                    actual.setElement(sucIn);
                    //para encontrar el más grande de lado izquierdo
                    actual.izq=borra(actual.izq,sucIn);
                } else {
                    //swap
                    T sucIn=findMin(actual.der);
                    actual.setElement(sucIn);
                    //
                    actual.der=borra(actual.der,sucIn);
                }//cierre del else
            }//cierre del else
        }//cierre del else
        //actualizar fe y altura
        actualiza(actual);
        //para checar los casos y balancear si necesario
        NodoAVL <T> aux = new NodoAVL();
        aux=balancea(actual);
        return aux;
    }//end borra
    
    //método auxiliar para encontrar el máximo
    public T findMax (NodoAVL <T> actual){
        //para verificar que existan datos en el árbol
        if (root!=null){
            T max = actual.getElement();
            //ciclo para recorrer el árbol
            while (actual.der!=null){
                //comparar para ver quién es el menor
                if (max.compareTo(actual.der.getElement())<0){
                    max=actual.getDer().getElement();
            }//cierre del if 
            //para continuar recorriendo el árbol
            actual = actual.getDer();
            }//find del while
            return max;
        } else
            throw new EmptyCollectionException("\nÁrbol vacío");
    }//end findMax
    
    //método auxiliar para encontrar el elemento mínimo
    public T findMin (NodoAVL <T> actual){
        //para verificar que existan datos en el árbol
        if (root!=null){
            T min = actual.getElement();
            //ciclo para recorrer el árbol
            while (actual.izq!=null){
                //comparar para ver quién es el menor
                if (min.compareTo(actual.getIzq().getElement())>0){
                    min=actual.getIzq().getElement();
            }//cierre del if 
            //para continuar recorriendo el árbol
            actual = actual.getIzq();
            }//find del while
            return min;
        } else
            throw new EmptyCollectionException("\nÁrbol vacío");
    }//end findMin
        
//--------------------------- SECCIÓN IMPRIMIR ---------------------------------

    // método para acomodar los elementos - LEVELORDER
    public Iterator<NodoAVL<T>> levelOrder(){
        ArrayList<NodoAVL<T>> lista= new ArrayList<NodoAVL<T>>();
        ColaA <NodoAVL<T>> cola= new ColaA();
        cola.agrega(root);
        while(!cola.estaVacia()){
           NodoAVL<T> actual=cola.quita();
            lista.add(actual);
            if(actual.getIzq()!=null)
                cola.agrega(actual.getIzq()); 
            if(actual.getDer()!=null)
                cola.agrega(actual.getDer());
        }//cierre del while 
        return lista.iterator();
    }//end levelOrder
    
    //método para imprimir el árbol por nivel (de izquierda a derecha)
    public StringBuilder imprime (){
        StringBuilder resp = new StringBuilder();
        Iterator <NodoAVL<T>> lista = levelOrder();
        //ciclo para recorrer el iterador
        while(lista.hasNext()){
            resp.append(lista.next().toString()).append("\n").append("\n");
        }//cierre del while
        return resp;
    }//end imprime
 
//--------------------------- SECCIÓN BUSCAR -----------------------------------
    
    //método público para buscar datos
    public NodoAVL <T> busca(T elem){
        if(elem!=null)
            return busca(root, elem);
        else
            return null;
    }//end find público
    
    //método auxiliar privado para buscar datos
    private NodoAVL <T> busca (NodoAVL<T> act, T elem){
        boolean enc=false;
        //while para recorrer el árbol
        while(!enc && act!=null){
            if(elem.compareTo(act.getElement())<0)
                act=act.getIzq();
            else{
                if(elem.compareTo(act.getElement())>0)
                    act=act.getDer();
                else
                    enc=true;
            }//cierre del else
        }//cierre del while
        if(enc)
            return act;
       else
            return null;
    }//end find
    
    //inicio del MAIN
    public static void main(String[] args) {
        AVLTree <Integer> tree = new AVLTree();
        
        //prueba insertar - OK
//        tree.inserta(100);
//        tree.inserta(200);
//        tree.inserta(300);
//        tree.inserta(10);
//        tree.inserta(5);
//        tree.inserta(4);
//        tree.inserta(50);
//        tree.inserta(110);
//        tree.inserta(115);
//        tree.inserta(37);
//        tree.inserta(12);
//        tree.inserta(29);
//        tree.inserta(1000);
//        tree.inserta(73);
//        tree.inserta(665);
//        tree.inserta(1);
//        tree.inserta(82);
        
//        System.out.println("\nNúmero de elementos: " + tree.count + "\n");
        
        //pruba buscar - OK
//        NodoAVL <Integer> busca1 = new NodoAVL();
//        busca1=tree.busca(50);
//        System.out.println("\n" + busca1.toString());
//        
//        NodoAVL <Integer> busca2 = new NodoAVL();
//        busca2=tree.busca(10);
//        System.out.println("\n" + busca2.toString());
//        
//        NodoAVL <Integer> busca3 = new NodoAVL();
//        busca3=tree.busca(1);
//        System.out.println("\n" + busca3.toString());
        
        //prueba imprimir - OK 
//        System.out.println(tree.imprime());

        //prueba de borrar - OK
//        System.out.println(tree.borra(110)); //true
//        System.out.println(tree.borra(4)); //true
//        System.out.println(tree.borra(50)); //true
//        System.out.println(tree.borra(489)); //false
        
        //pruba buscar después de borrar- OK
//        NodoAVL <Integer> busca1 = new NodoAVL();
//        busca1=tree.busca(110);
//        if(busca1==null)
//            System.out.println("\nNull"); //null
//        
//        NodoAVL <Integer> busca2 = new NodoAVL();
//        busca2=tree.busca(4);
//        if(busca2==null)
//            System.out.println("\nNull"); //null
//        
//        NodoAVL <Integer> busca3 = new NodoAVL();
//        busca3=tree.busca(50);
//        if(busca3==null)
//            System.out.println("\nNull"); //null
        
        //prueba imprimir luego de eliminar
//        System.out.println(tree.imprime());
    }//end main
}//end AVLTree
